from django.apps import AppConfig


class PromocodeConfig(AppConfig):
    name = 'promocode'
